# 1.3
-----
Added iframe support with script injection.

# 1.2
-----
Updated icons.

# 1.1
-----
Change code to search for the playing video.

# 1.0
-----
Initial release.
