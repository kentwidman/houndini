/*
 * Site it works on:
 * http://www.adultswim.com/videos/*
 * https://www.youtube.com/watch?v=*
 * https://www.hulu.com/*
 * http://www.cc.com/episodes/*
 * https://www.cnn.com/*
 * https://www.fox.com/*
 * 
 */
(function() {
  'use strict';
  // constants
  var MAX_PLAYBACK_RATE = 16.0;

  // var mutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
  var body = document.body;
  var button;
  var observer;

  // Selectors
  var videoSelector = 'video';

  // Timeout
  var resizeTimeout;

  //div.ad-showing

  function skipVideo() {
      // Your code here...
      var v;
      if (location.hostname.match(/hulu\.com/)) {
          //hulu fast forward
          v = document.querySelector('video');
          v.playbackRate = MAX_PLAYBACK_RATE;
      } else if (location.hostname.match(/cc\.com/)) {
          v = document.querySelector('.edge-player-ads-element');
          v.currentTime = v.duration;
      } else {
          v = document.querySelector('video');
          v.currentTime = v.duration;

          //Youtube skip button.
          setTimeout(function(){
              var skip = document.querySelector('.videoAdUiSkipButton');
              if (skip) {
                  skip.click();
              }
          },100);

      }
  }

  skipVideo();
})();
