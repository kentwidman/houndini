# 1.1
-----
Change code to search for the playing video.

# 1.0
-----
Initial release.
