/*
 * Site it works on:
 * http://www.adultswim.com/videos/*
 * https://www.youtube.com/watch?v=*
 * https://www.hulu.com/*
 * http://www.cc.com/episodes/*
 * https://www.cnn.com/*
 * https://www.fox.com/*
 *
 */
(function() {
  'use strict';
  // constants
  var MAX_PLAYBACK_RATE = 16.0;

  // var mutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
  var body = document.body;
  var button;
  var observer;

  // Selectors
  var videoSelector = 'video';

  // Timeout
  var resizeTimeout;

  // ads a helper "playing" to HTMLMediaElement
  Object.defineProperty(HTMLMediaElement.prototype, 'playing', {
    configurable: true, //Todo: fix this hack
    get: function(){
      return !!(this.currentTime > 0 && !this.paused && !this.ended && this.readyState > 2);
    }
  });

  function findPlayingVideo(){
    var selectedVideo = null;
    var videos = document.getElementsByTagName('video');
    for (var i = 0; i < videos.length; i++) {
      var video = videos[i];
      if (video.playing) {
        return video;
      }
    }
    console.log(video);

    // else return first video.
    return videos[0];
  }

  // div.ad-showing
  function skipVideo() {

    // Your code here...
    var v = findPlayingVideo();
    console.log(v);
    if (location.hostname.match(/hulu\.com/)) {
      //hulu fast forward
      v = document.querySelector('video');
      v.playbackRate = MAX_PLAYBACK_RATE;
    } else if (location.hostname.match(/cc\.com/)) {
      v = document.querySelector('.edge-player-ads-element');
      v.currentTime = v.duration;
    } else {
      v.currentTime = v.duration;

      //Youtube skip button.
      setTimeout(function(){
        var skip = document.querySelector('.videoAdUiSkipButton');
        if (skip) {
            skip.click();
        }
      },100);
    }
  }

  skipVideo();
})();
